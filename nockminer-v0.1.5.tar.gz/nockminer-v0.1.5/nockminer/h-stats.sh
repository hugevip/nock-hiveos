#!/usr/bin/env bash
. h-manifest.conf
logfile="/var/log/miner/custom/nockminer.log"

unit="p"
algo="nock"
version="0.1.5"

gpu_stats_nvidia=$(jq '[.brand, .temp, .fan, .power, .busids, .mtemp, .jtemp] | transpose | map(select(.[0] == "nvidia")) | transpose' <<< $gpu_stats)
gpu_temp=$(jq -c '[.[1][]]' <<< "$gpu_stats_nvidia")
gpu_fan=$(jq -c '[.[2][]]' <<< "$gpu_stats_nvidia")
gpu_bus=$(jq -c '[.[4][]]' <<< "$gpu_stats_nvidia")
gpu_count=$(jq '.busids | select(. != null) | length' <<< $gpu_stats)

# 1. 解析最新 Uptime，格式形如 3m31s 或 26s
last_uptime=$(grep "MINERLAB Uptime:" "$logfile" | tail -n1 | awk '{print $3}')

uptime=0
if [[ $last_uptime =~ ([0-9]+)m([0-9]+)s ]]; then
  # 匹配 XmYs 格式，计算秒数
  minutes=${BASH_REMATCH[1]}
  seconds=${BASH_REMATCH[2]}
  uptime=$((minutes * 60 + seconds))
elif [[ $last_uptime =~ ([0-9]+)s ]]; then
  # 只有秒，剔除s，直接赋值
  secs=${BASH_REMATCH[1]}
  uptime=$secs
else
  # 解析失败则0
  uptime=0
fi

# 1. 提取每个GPU的speed值
for i in $(seq 0 $((gpu_count - 1))); do
  # 倒序文件内容，找到第一个匹配项（即原文件中最后一个匹配项）
  val=$(tac "$logfile" | grep "Card-$i speed:" | head -n1 | sed -E "s/.*Card-$i speed: *([0-9.]+) p\/s.*/\1/")
  if [[ -z "$val" ]]; then
    val=0
  fi
  gpu_ats[$i]=$val
done

# 2. 计算总算力 (p/s)
total_attempts=0
for v in "${gpu_ats[@]}"; do
  total_attempts=$(echo "$total_attempts + $v" | bc)
done

# 3. 计算总算力 (kH/s)，这里假设1 p/s = 1 H/s
khs=$(echo "scale=3; $total_attempts / 1000" | bc)

# 取显卡busid值加入数组
for (( i=0; i <gpu_count ; i++ )); do
   busid=$(jq .[$i] <<< "$gpu_bus")
   bus_numbers[$i]=`echo $busid | cut -d ":" -f1 | cut -c2- | awk -F: '{ printf "%d\n",("0x"$1) }'`
done

# 直接使用gpu_ats数组生成hs_json，不进行额外计算
hs_json=$(printf '%s\n' "${gpu_ats[@]}" | jq -R . | jq -s .)

# --- 解析 Accepted by Pool 和 Rejected by Pool ---
accepted_by_pool=$(grep "MINERLAB Accepted by Pool:" "$logfile" | tail -n1 | awk '{print $5}')
rejected_by_pool=$(grep "MINERLAB Rejected by Pool:" "$logfile" | tail -n1 | awk '{print $5}')

[[ -z "$accepted_by_pool" ]] && accepted_by_pool=0
[[ -z "$rejected_by_pool" ]] && rejected_by_pool=0

stats=$(jq -n \
  --argjson bus_numbers "`echo ${bus_numbers[@]} | tr " " "\n" | jq -cs '.'`" \
  --argjson uptime "$uptime" \
  --argjson khs "$khs" \
  --arg algo "$algo" \
  --arg ver "$version" \
  --argjson temp "${gpu_temp}" \
  --argjson fan "${gpu_fan}" \
  --arg hs_units "$unit" \
  --argjson hs "$hs_json" \
  --argjson accepted "$accepted_by_pool" \
  --argjson rejected "$rejected_by_pool" \
  '{
    uptime: $uptime,
    khs: $khs,
    algo: $algo,
    ver: $ver,
    $temp, 
    $fan,
    hs_units: $hs_units,
    hs: $hs,
	ar: [$accepted, $rejected],
    bus_numbers: $bus_numbers
  }')

echo "$stats"
echo "$khs"