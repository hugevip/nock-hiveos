#!/usr/bin/env bash

####################################################################################
###
### Nockminer - Golden WXDN
###
#################################################################################### 

echo -e "${CYAN}          GOLDEN MINER - HiveOS WXDN                 ${RESET}"

echo -e "${BOLD}    Github du boss: https://github.com/zuolirui/ ️   ${RESET}"


. h-manifest.conf


count=0
./golden-miner-pool-prover $(< ./miner.conf) | while read -r line; do
  ((count++))
  if [ $count -gt 1 ]; then
    echo "$line"
  fi
done | tee -a "$CUSTOM_LOG_BASENAME.log"